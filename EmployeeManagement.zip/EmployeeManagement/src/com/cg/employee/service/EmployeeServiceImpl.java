package com.cg.employee.service;

import java.util.HashMap;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao dao;
	public void setDao(EmployeeDao dao)
	{
		this.dao = dao;
	}
	public EmployeeServiceImpl()
	{
		dao = new EmployeeDaoImpl();
	}
	@Override
	public Employee addEmployee(String name, int salary) {
		// TODO Auto-generated method stub
		int id = (int) (Math.random() * 25);
		Employee emp = new Employee(id,name,salary);
		return dao.addEmployee(emp);
	}

	@Override
	public Employee searchEmployee(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.searchEmployee(empId);
	}

	@Override
	public HashMap<Integer,Employee> getAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getAllEmployees();
	}
	

}
