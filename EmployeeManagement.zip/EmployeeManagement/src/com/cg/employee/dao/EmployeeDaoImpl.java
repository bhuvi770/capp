package com.cg.employee.dao;

import java.util.HashMap;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.util.StaticDB;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		StaticDB.getEmployee().put(emp.getEmpId(), emp);
		return emp;
	}

	@Override
	public Employee searchEmployee(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		Employee ref =null;
		if(StaticDB.getEmployee().containsKey(empId))
		{
			ref = StaticDB.getEmployee().get(empId);
		}
		else
			throw new EmployeeException("Employee not found");
		
		return ref;
	}

	@Override
	public HashMap<Integer, Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return StaticDB.getEmployee();
	}

}
