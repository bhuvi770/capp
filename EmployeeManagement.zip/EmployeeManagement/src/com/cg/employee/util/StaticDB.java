package com.cg.employee.util;

import java.util.HashMap;

import com.cg.employee.dto.Employee;

public class StaticDB {
	
	static HashMap<Integer,Employee> map;
	
	static
	{
		map = new HashMap<Integer,Employee>();
	}
	public static HashMap<Integer,Employee> getEmployee()
	{
		return map;
	}

}
