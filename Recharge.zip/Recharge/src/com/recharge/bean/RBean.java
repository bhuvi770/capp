package com.recharge.bean;

import java.time.LocalDate;


public class RBean {
	int bal ;
	String name;
	String mobNum;
	String plan;
	LocalDate date;
	String rechargeType;
	int rechargeID;
	String desc;

	
	public RBean() {
		// TODO Auto-generated constructor stub
	}
	
	public RBean(String name, String mobNum, String plan, String rechargeType, String desc) {

		this.name = name;
		this.mobNum = mobNum;
		this.plan = plan;
		this.rechargeType = rechargeType;
		this.desc = desc;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getBal() {
		return bal;
	}

	public void setBal(int bal) {
		this.bal = bal;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobNum() {
		return mobNum;
	}

	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getRechargeType() {
		return rechargeType;
	}

	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}

	public int getRechargeID() {
		return rechargeID;
	}

	public void setRechargeID(int rechargeID) {
		this.rechargeID = rechargeID;
	}

	public String toString() {
		return "RBean [name=" + name + ", mobNum=" + mobNum + ", plan=" + plan
				+ ", date=" + date + ", rechargeType=" + rechargeType
				+ ", rechargeID=" + rechargeID + "]";
	}
	
	
	
}
