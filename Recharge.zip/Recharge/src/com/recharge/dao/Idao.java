package com.recharge.dao;

import java.util.Collection;

import com.recharge.bean.RBean;

public interface Idao {

	public void addPlans();
	public void recharge(RBean r);
	public Collection<RBean> viewAllTransaction();
	public void clearHistory(int rid);
	public void updateDesc(int rid1 , String uDesc);
	public RBean viewByTransactionId(int id);
}
