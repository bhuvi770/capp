package com.recharge.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.recharge.bean.RBean;

public class DaoImpl implements Idao{

	static Map<String , String> plans = new HashMap<String , String>();
	static Map<Integer , RBean> m = new HashMap<Integer , RBean>();
	
	public void addPlans(){
		plans.put("RC99", "1 month Unlimited calls , 100 msgs per day, 1GB data\n");
		plans.put("RC199", "2 month Unlimited calls , 100 msgs per day, 1.5GB data\n");
		plans.put("RC399", "3 month Unlimited calls , 100 msgs per day, 2GB data\n");
		System.out.println("Availables plans are " +plans);
	}

	public void updateDesc(int rid1 , String uDesc){
		RBean r1=m.get(rid1);
		r1.setDesc(uDesc);
	}
	
	
	public void clearHistory(int rid){
		m.remove(rid);
	}
	
	@Override
	public void recharge(RBean r) {
		m.put(r.getRechargeID(), r);
		
	}

	@Override
	public Collection<RBean> viewAllTransaction() {
		return m.values();
	}

	@Override
	public RBean viewByTransactionId(int id) {
		return m.get(id);
		}
	}
	
	
	

