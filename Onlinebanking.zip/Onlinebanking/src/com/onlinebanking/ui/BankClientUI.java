package com.onlinebanking.ui;
import java.util.Scanner;

import com.onlinebanking.bean.Account;
import com.onlinebanking.service.BankingServiceImpl;
import com.onlinebanking.service.IBankingService;

public class BankClientUI {

	static Scanner scan = new Scanner(System.in);
	static IBankingService iserv=null;
	public static void main(String[] args) {

		System.out.println("enter any option b/1 to 5");
		System.out
				.println(" 1. Create Account \n 2. Update Account\n 3.delete Account");
		System.out.println("4. check All Transacions \n 5. transfer ");
		switch (scan.nextInt()) {

		case 1:
			int finalAccId=createAccount();
			System.out.println("account info is stored");
			System.out.println("ur account id is "+finalAccId);
			break;
		case 2:

			break;

		case 3:

			break;
		case 4:

			break;
		case 5:

			break;
		default:
			break;

		}
	}

	private static int createAccount() {
		System.out.println("enter the account name");
		String name=scan.next();
		System.out.println("enter the Mobile number");
		String mob=scan.next();
		System.out.println("enter the email");
		String email=scan.next();
		System.out.println("enter the Pan Number");
		String pan=scan.next();
		System.out.println("enter the account type");
		String accType=scan.next();
		System.out.println("enter the account opening balance");
		int balance=scan.nextInt();
		System.out.println("enter the branch");
		String branch=scan.next();
		
		//store it in bean
		Account account=new Account(name,mob,email,pan,accType,balance,branch);
		
		//validated
		String name1,mob1,pan1,balance1,email1,accType1;
		//validation is successfull
		iserv=new BankingServiceImpl();
		do{  
			
			System.out.println("You have entered a wrong name please Enter the correct account name");
			name=scan.next();
			}while(iserv.validateName(name)==false);  
		do{  
			System.out.println("enter the pan number again");
			pan=scan.next();
		 	}while(iserv.validatepan(pan)==false);
		
		do{  
			System.out.println("enter between savings and cuurent");
			pan=scan.next();
		 	}while(iserv.validatepan(accType)==false);
		
		do{  
			System.out.println("enter the correct mobile number");
			pan=scan.next();
		 	}while(iserv.validateMob(mob)==false);
		
		do{  
			System.out.println("enter the balance");
			pan=scan.next();
		 	}while(iserv.validatebalance(balance)==false);
		
		do{  
			System.out.println("enter the branch");
			pan=scan.next();
		 	}while(iserv.validateabranch(branch)==false);
		
		
		do{  
			System.out.println("enter the email id...");
			pan=scan.next();
		 	}while(iserv.validateemail(email)==false);
		
		
		
		
		
		
		
		int aid=iserv.createAccount(account);
		
		return aid;
	
	
		
	
	
	
	}

}
