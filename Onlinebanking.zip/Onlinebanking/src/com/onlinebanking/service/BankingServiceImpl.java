package com.onlinebanking.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.onlinebanking.bean.Account;
import com.onlinebanking.dao.BankingDaoImpl;
import com.onlinebanking.dao.IBankingdao;

public class BankingServiceImpl  implements IBankingService{
	IBankingdao idao=null;
	Matcher m=null;
	private int generateAccountId(){
		return (int)Math.random()*10000;
	}
	@Override
	public int createAccount(Account acc) {
		acc.setAccountId(generateAccountId());//modicf
		//pass to dao
		
		idao=new BankingDaoImpl();
		return idao.createAccount(acc);
	}

	@Override
	public void updateAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withDraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkAllTransactions() {
		// TODO Auto-generated method stub
		
	}
	public boolean validateName(String name)
	{
		m=Pattern.compile("^[A-Z][a-z]{3,}$").matcher(name);
				if(m.find())
				{
		return true;
				}else
				return false;
}
	public boolean validateMob(String mob){
		
		m=Pattern.compile("^[0-9]{0,}{1,}9(?!8)").matcher(mob);
		if(m.find())
		return true;
		else
                 return false;
	}
		public boolean validatepan(String pan){
    	  
			m=Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}").matcher(pan);
			if(m.find())
				return true;
				else
		        return false;
		}		
		
		public boolean validatebalance(int balance){
			
		if(balance>500)
			return true;
		else 
			return false;
		}
		
		public boolean validateemail(String email){
			m=Pattern.compile("^[A-Z,a-z,0-9.])[1,]@gmail.com$").matcher(email);
	if(m.find())
		return true;
	else
		return false;
		}
	
         public boolean validateaccType(String accType){
        	 
         if(accType.equalsIgnoreCase("Saving")|| accType.equalsIgnoreCase("Current"))
      return true;
            else
             	 return false;
         }
         
         public boolean validateabranch(String branch){
        	 if(branch.equalsIgnoreCase("chennai"))
        	 return true;
        	 else
        		 return false;
        	 
         }
        	 
        	 
        	 
        	 
        	 
         
         
         
         
         
}