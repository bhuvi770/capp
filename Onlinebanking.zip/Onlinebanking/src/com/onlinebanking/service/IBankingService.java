package com.onlinebanking.service;

import com.onlinebanking.bean.Account;

public interface IBankingService {
	public int createAccount(Account acc);
	public void	updateAccount();
	public void deleteAccount();
	public void withDraw();
	public void checkAllTransactions();
	//public boolean validateName();
	public boolean validateName(String name);
	//public boolean validateMob();
	public boolean validateMob(String mob);
	//public boolean validateMob();
	public boolean validatepan(String pan);
	//public boolean validatepan();
	public boolean validatebalance(int balance);
	//public boolean validatebalance();
	public boolean validateabranch(String branch);	
	//public boolean validatebranch();
	public boolean validateemail(String email);
	//public boolean validateemail();
}
